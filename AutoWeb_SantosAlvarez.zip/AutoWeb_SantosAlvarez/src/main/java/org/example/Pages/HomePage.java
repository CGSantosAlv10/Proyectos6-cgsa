package org.example.Pages;

import net.serenitybdd.annotations.DefaultUrl;
import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;

@DefaultUrl("https://www.demoblaze.com/")

public class HomePage extends PageObject {

    // 01. Registrar sesión

    public static final Target BTN_REGISTRAR = Target.the("Boton para hacer el registro")
            .located(By.id("signin2"));
    public static final Target INP_USERNAME = Target.the("Input para ingresar username")
            .located(By.id("sign-username"));
    public static final Target INP_PASSWORD = Target.the("Input para ingresar password")
            .located(By.id("sign-password"));
    public static final Target BTN_REGISTRAR2 = Target.the("Input para ingresar password")
            .located(By.xpath("//button[text()='Sign up']"));

    // 02. Iniciar sesión

    public static final Target BTN_LOGIN =
            Target.the("Boton para abrir el inicio de sesion")
                    .located(By.id("login2"));
    public static final Target INP_LOGIN_USERNAME =
            Target.the("Campo de usuario para iniciar sesion")
                    .located(By.id("loginusername"));
    public static final Target INP_LOGIN_PASSWORD =
            Target.the("Campo de contraseña para iniciar sesion")
                    .located(By.id("loginpassword"));
    public static final Target BTN_LOGIN_CONFIRMAR =
            Target.the("Boton para confirmar el inicio de sesion")
                    .located(By.xpath("//button[text()='Log in']"));
}
