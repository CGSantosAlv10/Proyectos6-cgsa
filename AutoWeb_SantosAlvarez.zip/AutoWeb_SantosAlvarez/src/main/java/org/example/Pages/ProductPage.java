package org.example.Pages;

import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;

public class ProductPage extends PageObject {

    // Información del producto

    public static final Target TXT_NOMBRE_PRODUCTO =
            Target.the("Nombre del producto")
                    .located(By.xpath("//*[@id=\"tbodyid\"]/h2"));
    public static final Target TXT_PRECIO_PRODUCTO =
            Target.the("Precio del producto")
                    .located(By.xpath("//*[@id=\"tbodyid\"]/h3"));
    public static final Target TXT_DESCRIPCION_PRODUCTO =
            Target.the("Descripción del producto")
                    .located(By.xpath("//*[@id=\"more-information\"]/p"));

    // 03. Navegación y selección de productos

    public static final Target BTN_CATEGORIA_LAPTOPS =
            Target.the("Categoría Laptops")
                    .located(By.xpath("//a[@id='itemc' and normalize-space()='Laptops']"));
    public static final Target LNK_SONY_VAIO =
            Target.the("Producto Sony vaio i5")
                    .located(By.xpath("//a[normalize-space()='Sony vaio i5']"));

    // 04. Agregar producto al carrito

    public static final Target BTN_AGREGAR_CARRITO =
            Target.the("Boton para agregar el producto al carrito")
                    .located(By.xpath("//*[@id=\"tbodyid\"]/div[2]/div/a"));
}
