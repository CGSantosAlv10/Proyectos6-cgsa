package org.example.Pages;

import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;

public class CartPage extends PageObject {

    // 04. Navegación al carrito
    public static final Target BTN_CARRITO =
            Target.the("Enlace para acceder al carrito")
                    .located(By.id("cartur"));

    // Producto en el carrito
    public static final Target TXT_NOMBRE_PRODUCTO_CARRITO =
            Target.the("Nombre del producto agregado al carrito")
                    .located(By.xpath("//*[@id=\"tbodyid\"]/tr/td[2]"));
}