package org.example.Utils;

import io.cucumber.java.*;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import org.openqa.selenium.JavascriptExecutor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static net.thucydides.core.webdriver.ThucydidesWebDriverSupport.getDriver;

public class PreAndProsCondition {

    private static final Logger LOGGER =
            LoggerFactory.getLogger(PreAndProsCondition.class);

    private static String screenShot = Parameters.RutaEvidencia;

    public static String getScreenShot() {
        return screenShot;
    }

    private static void setScreenShot(String path) {
        screenShot = path;
    }

    @Before
    public void beforeScenario(Scenario scenario) {
        LOGGER.info("____________________________________________");
        LOGGER.info("Running scenario");

        OnStage.setTheStage(new OnlineCast());

        LOGGER.info("Creating folder for screenshot");

        setScreenShot(Parameters.RutaEvidencia
                + ScreenShot.getCurrentDateTime()
                + "_" + scenario.getName());

        ScreenShot.createFolder(getScreenShot());

        // Limpiar sesión del usuario
        JavascriptExecutor jsExecutor = (JavascriptExecutor) getDriver();
        jsExecutor.executeScript("localStorage.removeItem('settings');");
        jsExecutor.executeScript("sessionStorage.removeItem('username');");
        jsExecutor.executeScript("sessionStorage.removeItem('NRBA_SESSION_ID');");
    }

    @After
    public void afterScenario(Scenario scenario) {
        LOGGER.info("Finishing scenario");
        setScreenShot(Parameters.RutaEvidencia);
    }

    @BeforeStep
    public void beforeStep(Scenario scenario) {
        LOGGER.info("Executing scenario steps");
    }
}
