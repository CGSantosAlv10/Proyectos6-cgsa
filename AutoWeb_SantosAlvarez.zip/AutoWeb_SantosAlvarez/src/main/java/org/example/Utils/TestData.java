package org.example.Utils;

public class TestData {

    // Credenciales compartidas para las pruebas de registro e inicio de sesion

    public static final String USERNAME = "cesantosa10";
    public static final String PASSWORD = "987654321";
}
