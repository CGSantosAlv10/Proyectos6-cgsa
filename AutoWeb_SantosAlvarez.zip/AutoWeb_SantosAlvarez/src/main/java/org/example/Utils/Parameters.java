package org.example.Utils;

public class Parameters {
    // ------------------- RUTAS --------------------------------------
    public static final String RutaEvidencia = "/evidencias/";

}