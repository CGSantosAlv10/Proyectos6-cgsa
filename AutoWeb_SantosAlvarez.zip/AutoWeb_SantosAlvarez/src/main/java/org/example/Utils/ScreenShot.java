package org.example.Utils;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ScreenShot {

    public static String captureScreenshot(WebDriver driver, String folder) {
        return captureScreenshot(driver, folder, "");
    }

    public static String captureScreenshot(WebDriver driver, String folder, String screenName) {
        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

        Path basePath = Paths.get(System.getProperty("user.dir"))
                .toAbsolutePath().normalize();

        Path evidenceFolder = basePath
                .resolve(folder.replaceFirst("^[/\\\\]+", ""))
                .normalize();

        if (!evidenceFolder.startsWith(basePath)) {
            throw new SecurityException("Invalid screenshot folder path");
        }

        String safeScreenName = screenName.replaceAll("[^a-zA-Z0-9_-]", "_");

        String fileName = "evidencia_" + getCurrentDateTime()
                + (safeScreenName.isEmpty() ? "" : "_" + safeScreenName)
                + ".png";

        Path screenshotPath = evidenceFolder.resolve(fileName).normalize();

        if (!screenshotPath.startsWith(evidenceFolder)) {
            throw new SecurityException("Invalid screenshot file path");
        }

        try {
            Files.createDirectories(evidenceFolder);
            Files.copy(src.toPath(), screenshotPath,
                    StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            throw new IllegalStateException("Unable to capture screenshot", e);
        }

        return screenshotPath.toString();
    }

    public static String getCurrentDateTime() {
        DateFormat customFormat = new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss");
        Date currentDate = new Date();
        return customFormat.format(currentDate);
    }

    public static void createFolder(String folderName) {
        Path basePath = Paths.get(System.getProperty("user.dir"))
                .toAbsolutePath().normalize();

        Path folder = basePath
                .resolve(folderName.replaceFirst("^[/\\\\]+", ""))
                .normalize();

        if (!folder.startsWith(basePath)) {
            throw new SecurityException("Invalid resource path");
        }

        try {
            Files.createDirectories(folder);
        } catch (IOException e) {
            throw new IllegalStateException("Could not create evidence folder", e);
        }
    }
}
