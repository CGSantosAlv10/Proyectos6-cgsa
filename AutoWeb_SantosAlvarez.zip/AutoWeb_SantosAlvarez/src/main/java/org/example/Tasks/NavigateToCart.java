package org.example.Tasks;

import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.waits.WaitUntil;
import org.example.Pages.CartPage;

import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.isVisible;

public class NavigateToCart {

    public static Performable theShoppingCart() {
        return Task.where("{0} accede al carrito de compras",

                WaitUntil.the(
                        CartPage.BTN_CARRITO,
                        isVisible()
                ).forNoMoreThan(10).seconds(),

                Click.on(CartPage.BTN_CARRITO)
        );
    }
}