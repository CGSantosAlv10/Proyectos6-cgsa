package org.example.Tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import org.example.Pages.HomePage;

import static net.serenitybdd.screenplay.Tasks.instrumented;

public class LogIn implements Task {

    private final String username;
    private final String password;

    public LogIn(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public static LogIn conCredenciales(String username, String password) {
        return instrumented(LogIn.class, username, password);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(HomePage.BTN_LOGIN),
                Enter.theValue(username).into(HomePage.INP_LOGIN_USERNAME),
                Enter.theValue(password).into(HomePage.INP_LOGIN_PASSWORD),
                Click.on(HomePage.BTN_LOGIN_CONFIRMAR)
        );
    }
}
