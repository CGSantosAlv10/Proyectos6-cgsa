package org.example.Tasks;

import net.serenitybdd.screenplay.Performable;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.waits.WaitUntil;
import org.example.Pages.ProductPage;

import static net.serenitybdd.screenplay.matchers.WebElementStateMatchers.isVisible;

public class NavigateToProduct {

    public static Performable theSonyVaio() {
        return Task.where("{0} selecciona el producto Sony vaio i5",

                WaitUntil.the(
                        ProductPage.LNK_SONY_VAIO,
                        isVisible()
                ).forNoMoreThan(10).seconds(),

                Click.on(ProductPage.LNK_SONY_VAIO)
        );
    }
}
