package org.example.Questions;

import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class ResponseCode {

    public static Question<String> alertMessage() {
        return actor -> {
            WebDriverWait wait = new WebDriverWait(
                    BrowseTheWeb.as(actor).getDriver(),
                    Duration.ofSeconds(5)
            );

            Alert alert = wait.until(ExpectedConditions.alertIsPresent());
            String text = alert.getText();
            alert.accept();

            return text;
        };
    }

    public static Question<String> loggedInUser() {
        return actor -> {
            WebDriverWait wait = new WebDriverWait(
                    BrowseTheWeb.as(actor).getDriver(),
                    Duration.ofSeconds(10)
            );

            WebElement welcomeMessage = wait.until(
                    ExpectedConditions.visibilityOfElementLocated(
                            By.id("nameofuser")
                    )
            );

            return welcomeMessage.getText();
        };
    }
}
