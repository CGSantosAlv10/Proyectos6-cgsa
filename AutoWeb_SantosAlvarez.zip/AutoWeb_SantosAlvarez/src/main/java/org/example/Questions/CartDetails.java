package org.example.Questions;

import net.serenitybdd.screenplay.Question;
import org.example.Pages.CartPage;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class CartDetails {

    public static Question<String> productName() {
        return actor -> {
            WebDriverWait wait = new WebDriverWait(
                    net.serenitybdd.screenplay.abilities.BrowseTheWeb.as(actor).getDriver(),
                    Duration.ofSeconds(10)
            );

            return wait.until(ExpectedConditions.visibilityOf(
                    CartPage.TXT_NOMBRE_PRODUCTO_CARRITO.resolveFor(actor)
            )).getText();
        };
    }
}