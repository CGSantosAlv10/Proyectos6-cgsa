package org.example.Questions;

import net.serenitybdd.screenplay.Question;
import org.example.Pages.ProductPage;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class ProductDetails {

    public static Question<String> productName() {
        return actor -> {
            WebDriverWait wait = new WebDriverWait(
                    net.serenitybdd.screenplay.abilities.BrowseTheWeb.as(actor).getDriver(),
                    Duration.ofSeconds(10)
            );

            return wait.until(ExpectedConditions.visibilityOf(
                    ProductPage.TXT_NOMBRE_PRODUCTO.resolveFor(actor)
            )).getText();
        };
    }

    public static Question<String> productPrice() {
        return actor -> {
            WebDriverWait wait = new WebDriverWait(
                    net.serenitybdd.screenplay.abilities.BrowseTheWeb.as(actor).getDriver(),
                    Duration.ofSeconds(10)
            );

            return wait.until(ExpectedConditions.visibilityOf(
                    ProductPage.TXT_PRECIO_PRODUCTO.resolveFor(actor)
            )).getText();
        };
    }

    public static Question<String> productDescription() {
        return actor -> {
            WebDriverWait wait = new WebDriverWait(
                    net.serenitybdd.screenplay.abilities.BrowseTheWeb.as(actor).getDriver(),
                    Duration.ofSeconds(10)
            );

            return wait.until(ExpectedConditions.visibilityOf(
                    ProductPage.TXT_DESCRIPCION_PRODUCTO.resolveFor(actor)
            )).getText();
        };
    }
}
