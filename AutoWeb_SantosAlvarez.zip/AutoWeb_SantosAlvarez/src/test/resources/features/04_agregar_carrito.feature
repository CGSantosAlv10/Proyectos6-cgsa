Feature: Agregar productos al carrito

  @AgregarCarrito @HappyPath
  Scenario: Agregar un producto al carrito de compras
    Given el usuario esta en la pagina principal
    When selecciona la categoría Laptops
    And selecciona el producto Sony vaio i5
    And agrega el producto al carrito
    Then se muestra el mensaje de confirmación
    And el producto aparece en el carrito