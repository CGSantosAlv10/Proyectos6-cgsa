Feature: Seleccionar productos

  @SeleccionarProducto @HappyPath
  Scenario: Seleccionar un producto de la categoría Laptops
    Given el usuario esta en la pagina principal
    When selecciona la categoría Laptops
    And selecciona el producto Sony vaio i5
    Then se muestran correctamente los datos del producto
