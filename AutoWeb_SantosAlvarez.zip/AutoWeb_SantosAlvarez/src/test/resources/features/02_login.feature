Feature: Inicio de sesion de usuario

  @Login @HappyPath
  Scenario: Iniciar sesion con credenciales validas
    Given el usuario está en la pagina de inicio
    And selecciona el boton de inicio de sesion
    And ingresa las credenciales de inicio de sesion
    When selecciona el boton de log in
    Then se inicia sesion de manera exitosa