Feature: Registrar nuevo usuario
  @RegistrarNew @HappyPath
  Scenario: Registrar de manera exitosa un usuario con datos validos
    Given el usuario esta en la pagina de inicio
    And selecciona el boton de registro
    And ingresa las credenciales de registro
    When seleccion el boton registrar
    Then realiza el registro de manera exitosa
