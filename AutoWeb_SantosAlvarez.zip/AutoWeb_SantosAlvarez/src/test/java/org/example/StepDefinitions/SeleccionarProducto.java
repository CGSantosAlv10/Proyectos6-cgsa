
package org.example.StepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actions.Click;

import org.example.Pages.ProductPage;
import org.example.Questions.ProductDetails;
import org.example.Tasks.NavigateHome;
import org.example.Tasks.NavigateToProduct;
import org.example.Utils.PreAndProsCondition;
import org.example.Utils.ScreenShot;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static net.serenitybdd.core.Serenity.getDriver;

import org.hamcrest.Matchers;

public class SeleccionarProducto {

    @Given("el {actor} esta en la pagina principal")
    public void elUsuarioEstaEnLaPaginaPrincipal(Actor actor) {
        actor.attemptsTo(NavigateHome.theHomePage());

        ScreenShot.captureScreenshot(
                getDriver(),
                PreAndProsCondition.getScreenShot(),
                "Paso 1"
        );
    }

    @When("selecciona la categoría Laptops")
    public void seleccionaLaCategoriaLaptops() {
        theActorInTheSpotlight().attemptsTo(
                Click.on(ProductPage.BTN_CATEGORIA_LAPTOPS)
        );

        ScreenShot.captureScreenshot(
                getDriver(),
                PreAndProsCondition.getScreenShot(),
                "Paso 2"
        );
    }

    @And("selecciona el producto Sony vaio i5")
    public void seleccionaElProductoSonyVaioI5() {
        theActorInTheSpotlight().attemptsTo(
                NavigateToProduct.theSonyVaio()
        );

        ScreenShot.captureScreenshot(
                getDriver(),
                PreAndProsCondition.getScreenShot(),
                "Paso 3"
        );
    }

    @Then("se muestran correctamente los datos del producto")
    public void seMuestranCorrectamenteLosDatosDelProducto() {
        theActorInTheSpotlight().should(
                seeThat(
                        ProductDetails.productName(),
                        Matchers.equalTo("Sony vaio i5")
                ),
                seeThat(
                        ProductDetails.productPrice(),
                        Matchers.not(Matchers.isEmptyOrNullString())
                ),
                seeThat(
                        ProductDetails.productDescription(),
                        Matchers.not(Matchers.isEmptyOrNullString())
                )
        );

        ScreenShot.captureScreenshot(
                getDriver(),
                PreAndProsCondition.getScreenShot(),
                "Paso 4"
        );
    }
}
