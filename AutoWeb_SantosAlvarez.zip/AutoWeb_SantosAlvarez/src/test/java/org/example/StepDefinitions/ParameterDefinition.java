package org.example.StepDefinitions;

import io.cucumber.java.Before;
import io.cucumber.java.ParameterType;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;

public class ParameterDefinition
{
    @ParameterType("usuario")
    public Actor actor(String actorName){
        return OnStage.theActorCalled(actorName);
    }
    @Before
    public void setThStage(){
        OnStage.setTheStage(new OnlineCast());
    }
}
