package org.example.StepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.example.Questions.CartDetails;
import org.example.Questions.ResponseCode;
import org.example.Tasks.AddProductToCart;
import org.example.Tasks.NavigateToCart;
import org.example.Utils.PreAndProsCondition;
import org.example.Utils.ScreenShot;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static net.serenitybdd.core.Serenity.getDriver;

import org.hamcrest.Matchers;

public class AgregarAlCarrito {

    @And("agrega el producto al carrito")
    public void agregaElProductoAlCarrito() {
        theActorInTheSpotlight().attemptsTo(
                AddProductToCart.theSelectedProduct()
        );
    }

    @Then("se muestra el mensaje de confirmación")
    public void seMuestraElMensajeDeConfirmacion() {
        theActorInTheSpotlight().should(
                seeThat(
                        ResponseCode.alertMessage(),
                        Matchers.containsString("Product added")
                )
        );

        ScreenShot.captureScreenshot(
                getDriver(),
                PreAndProsCondition.getScreenShot(),
                "Paso 4"
        );
    }

    @And("el producto aparece en el carrito")
    public void elProductoApareceEnElCarrito() {
        theActorInTheSpotlight().attemptsTo(
                NavigateToCart.theShoppingCart()
        );
        theActorInTheSpotlight().should(
                seeThat(
                        CartDetails.productName(),
                        Matchers.equalTo("Sony vaio i5")
                )
        );

        ScreenShot.captureScreenshot(
                getDriver(),
                PreAndProsCondition.getScreenShot(),
                "Paso 5"
        );
    }
}
