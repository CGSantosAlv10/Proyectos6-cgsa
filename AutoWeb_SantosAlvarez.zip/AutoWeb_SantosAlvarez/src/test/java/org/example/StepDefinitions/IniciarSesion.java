
package org.example.StepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import net.serenitybdd.screenplay.Actor;
import org.example.Pages.HomePage;
import org.example.Questions.ResponseCode;
import org.example.Tasks.NavigateHome;
import org.example.Utils.TestData;
import org.example.Utils.PreAndProsCondition;
import org.example.Utils.ScreenShot;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.Matchers.containsString;
import static net.serenitybdd.core.Serenity.getDriver;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;

public class IniciarSesion {

    @Given("el {actor} está en la pagina de inicio")
    public void elUsuarioEstaEnLaPaginaDeInicio(Actor actor) {
        actor.attemptsTo(NavigateHome.theHomePage());
        ScreenShot.captureScreenshot(
                getDriver(),
                PreAndProsCondition.getScreenShot(),
                "Paso 1"
        );
    }

    @And("selecciona el boton de inicio de sesion")
    public void seleccionaElBotonDeInicioDeSesion() {
        theActorInTheSpotlight().attemptsTo(
                Click.on(HomePage.BTN_LOGIN));

        ScreenShot.captureScreenshot(
                getDriver(),
                PreAndProsCondition.getScreenShot(),
                "Paso 2"
        );
    }

    @And("ingresa las credenciales de inicio de sesion")
    public void ingresaLasCredencialesDeInicioDeSesion() {
        theActorInTheSpotlight().attemptsTo(
                Enter.theValue(TestData.USERNAME).into(HomePage.INP_LOGIN_USERNAME),
                Enter.theValue(TestData.PASSWORD).into(HomePage.INP_LOGIN_PASSWORD));

        ScreenShot.captureScreenshot(
                getDriver(),
                PreAndProsCondition.getScreenShot(),
                "Paso 3"
        );
    }

    @When("selecciona el boton de log in")
    public void seleccionaElBotonDeLogIn() {
        theActorInTheSpotlight().attemptsTo(
                Click.on(HomePage.BTN_LOGIN_CONFIRMAR));
    }

    @Then("se inicia sesion de manera exitosa")
    public void seIniciaSesionDeManeraExitosa() {
        theActorInTheSpotlight().should(
                seeThat(
                        ResponseCode.loggedInUser(),
                        containsString(TestData.USERNAME)));

        ScreenShot.captureScreenshot(
                getDriver(),
                PreAndProsCondition.getScreenShot(),
                "Paso 4"
        );
    }
}
