package org.example.StepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import org.example.Pages.HomePage;
import org.example.Questions.ResponseCode;
import org.example.Tasks.NavigateHome;
import org.example.Utils.PreAndProsCondition;
import org.example.Utils.ScreenShot;
import org.example.Utils.TestData;

import static net.serenitybdd.core.Serenity.getDriver;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.CoreMatchers.equalTo;

public class RegistrarUsuario {

    @Given("el {actor} esta en la pagina de inicio")
    public void elUsuarioEstaEnLaPaginaDeInicio(Actor actor) {
        actor.attemptsTo(NavigateHome.theHomePage());
        ScreenShot.captureScreenshot(
                getDriver(),
                PreAndProsCondition.getScreenShot(),
                "Paso 1"
        );
    }

    @And("selecciona el boton de registro")
    public void seleccionaElBotonDeRegistro() {
        theActorInTheSpotlight().attemptsTo(Click.on(HomePage.BTN_REGISTRAR));

        ScreenShot.captureScreenshot(
                getDriver(),
                PreAndProsCondition.getScreenShot(),
                "Paso 2"
        );
    }

    @And("ingresa las credenciales de registro")
    public void ingresaLasCredencialesDeRegistro() {
        theActorInTheSpotlight().attemptsTo(
                Enter.theValue(TestData.USERNAME).into(HomePage.INP_USERNAME),
                Enter.theValue(TestData.PASSWORD).into(HomePage.INP_PASSWORD)
        );

        ScreenShot.captureScreenshot(
                getDriver(),
                PreAndProsCondition.getScreenShot(),
                "Paso 3"
        );
    }

    @When("seleccion el boton registrar")
    public void seleccionElBotonRegistrar() {
        theActorInTheSpotlight().attemptsTo(Click.on(HomePage.BTN_REGISTRAR2));
    }

    @Then("realiza el registro de manera exitosa")
    public void realizaElRegistroDeManeraExitosa() {
        theActorInTheSpotlight().should(
                seeThat(
                        ResponseCode.alertMessage(),
                        equalTo("Sign up successful."))
        );
    }
}
